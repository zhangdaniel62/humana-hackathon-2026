import { useState, useEffect, useRef } from "react";
import {
  Phone, PhoneOff, CheckCircle, AlertTriangle, Clock,
  Activity, Cpu, ChevronRight, UserCheck, ShieldQuestion, ChevronDown
} from "lucide-react";
import humanaLogo from "../../humanalogo.jpeg";

type QueueStatus = "connecting" | "active" | "analyzing";
type OutcomeStatus = "resolved" | "escalated";

interface MemberRecord {
  memberId: string;
  name: string;
  phone: string;
  planId: string;
  planType: string;
  claimId: string;
  procedure: string;
  cptCode: string;
  denialCode: string;
  denialReason: string;
  billedAmount: number;
  agent: string;
}

interface ActiveCaller {
  id: string;
  phone: string;
  reason: string;
  subReason: string;
  agents: string[];
  duration: number;
  status: QueueStatus;
  _record: MemberRecord;
}

interface CompletedCaller {
  id: string;
  phone: string;
  name: string;
  memberId: string;
  planId: string;
  claimId: string;
  reason: string;
  agents: string[];
  outcome: OutcomeStatus;
  duration: number;
  summary: string;
  completedAt: Date;
}

// Real data from members.csv + claims.csv — phone normalized, extensions stripped
const MEMBER_POOL: MemberRecord[] = [
  {
    memberId: "MBR00019", name: "Elizabeth King", phone: "(789) 811-3529",
    planId: "PLAN-PPO-861", planType: "PPO",
    claimId: "CLM000077", procedure: "Total Knee Arthroplasty", cptCode: "27447",
    denialCode: "CO-11", denialReason: "Diagnosis inconsistent with procedure",
    billedAmount: 2463.53, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00031", name: "Kelly Carson", phone: "(225) 224-1913",
    planId: "PLAN-DSNP-286", planType: "DSNP",
    claimId: "CLM000127", procedure: "Total Knee Arthroplasty", cptCode: "27447",
    denialCode: "CO-B7", denialReason: "Provider not certified for this service",
    billedAmount: 823.80, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00107", name: "Ana Ruiz", phone: "(781) 479-4695",
    planId: "PLAN-DSNP-205", planType: "DSNP",
    claimId: "CLM000482", procedure: "Upper GI Endoscopy with Biopsy", cptCode: "43239",
    denialCode: "CO-B7", denialReason: "Provider not certified for this service",
    billedAmount: 4316.77, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00041", name: "Michael Daniel", phone: "(665) 286-1793",
    planId: "PLAN-PPO-372", planType: "PPO",
    claimId: "CLM000172", procedure: "Total Knee Arthroplasty", cptCode: "27447",
    denialCode: "CO-167", denialReason: "Diagnosis not covered",
    billedAmount: 2925.99, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00047", name: "Jeremy Mcintyre", phone: "(723) 530-3070",
    planId: "PLAN-PPO-826", planType: "PPO",
    claimId: "CLM000200", procedure: "Total Knee Arthroplasty", cptCode: "27447",
    denialCode: "CO-97", denialReason: "Benefit included in payment for another service",
    billedAmount: 3635.78, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00055", name: "Andrea Reyes", phone: "(327) 853-2697",
    planId: "PLAN-HMO-915", planType: "HMO",
    claimId: "CLM000244", procedure: "Total Knee Arthroplasty", cptCode: "27447",
    denialCode: "CO-29", denialReason: "Time limit for filing has expired",
    billedAmount: 4418.61, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00022", name: "Robert Herrera", phone: "(424) 799-1251",
    planId: "PLAN-DSNP-405", planType: "DSNP",
    claimId: "CLM000096", procedure: "Screening Mammography, Bilateral", cptCode: "77067",
    denialCode: "CO-29", denialReason: "Time limit for filing has expired",
    billedAmount: 2435.55, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00042", name: "Carolyn Bennett", phone: "(653) 536-8844",
    planId: "PLAN-MAPD-378", planType: "MAPD",
    claimId: "CLM000177", procedure: "Screening Mammography, Bilateral", cptCode: "77067",
    denialCode: "CO-50", denialReason: "Non-covered service",
    billedAmount: 1753.49, agent: "Benefits Q&A Agent",
  },
  {
    memberId: "MBR00043", name: "Christian Ward", phone: "(918) 962-5652",
    planId: "PLAN-DSNP-690", planType: "DSNP",
    claimId: "CLM000180", procedure: "Screening Mammography, Bilateral", cptCode: "77067",
    denialCode: "CO-50", denialReason: "Non-covered service",
    billedAmount: 3046.66, agent: "Benefits Q&A Agent",
  },
  {
    memberId: "MBR00010", name: "Thomas Boone", phone: "(337) 935-4033",
    planId: "PLAN-MAPD-436", planType: "MAPD",
    claimId: "CLM000040", procedure: "Blood Glucose Test", cptCode: "82962",
    denialCode: "CO-16", denialReason: "Claim lacks information needed for adjudication",
    billedAmount: 1923.00, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00001", name: "Joseph Hoffman", phone: "(843) 875-7584",
    planId: "PLAN-PPO-692", planType: "PPO",
    claimId: "CLM000003", procedure: "Hemoglobin A1c (HbA1c) Test", cptCode: "83036",
    denialCode: "CO-97", denialReason: "Benefit included in payment for another service",
    billedAmount: 4818.08, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00025", name: "Laura Patel", phone: "(623) 825-3672",
    planId: "PLAN-DSNP-954", planType: "DSNP",
    claimId: "CLM000105", procedure: "Psychotherapy, 60 min", cptCode: "90837",
    denialCode: "PR-1", denialReason: "Deductible amount",
    billedAmount: 716.45, agent: "Benefits Q&A Agent",
  },
  {
    memberId: "MBR00039", name: "Andrew Brown", phone: "(829) 321-8515",
    planId: "PLAN-DSNP-776", planType: "DSNP",
    claimId: "CLM000038", procedure: "Office Visit - Level 4", cptCode: "99214",
    denialCode: "CO-16", denialReason: "Claim lacks information needed for adjudication",
    billedAmount: 3883.11, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00096", name: "Sarah Mcfarland", phone: "(264) 862-2517",
    planId: "PLAN-DSNP-667", planType: "DSNP",
    claimId: "CLM000064", procedure: "Office Visit - Level 3", cptCode: "99213",
    denialCode: "CO-16", denialReason: "Claim lacks information needed for adjudication",
    billedAmount: 4804.58, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00157", name: "April Gonzalez", phone: "(295) 543-1652",
    planId: "PLAN-DSNP-523", planType: "DSNP",
    claimId: "CLM000695", procedure: "Depression Screening", cptCode: "96127",
    denialCode: "CO-167", denialReason: "Diagnosis not covered",
    billedAmount: 2647.65, agent: "Claim Story Agent",
  },
  {
    memberId: "MBR00133", name: "Michael Hodge", phone: "(780) 246-4989",
    planId: "PLAN-DSNP-831", planType: "DSNP",
    claimId: "CLM000130", procedure: "Electrocardiogram (ECG/EKG)", cptCode: "93000",
    denialCode: "CO-109", denialReason: "Claim not covered — coordination of benefits",
    billedAmount: 4268.64, agent: "ROI Gatekeeper",
  },
  {
    memberId: "MBR00112", name: "Emma Alexander", phone: "(949) 232-1495",
    planId: "PLAN-DSNP-826", planType: "DSNP",
    claimId: "CLM000569", procedure: "Chronic Care Management (20 min)", cptCode: "99490",
    denialCode: "CO-109", denialReason: "Claim not covered — coordination of benefits",
    billedAmount: 402.61, agent: "ROI Gatekeeper",
  },
  {
    memberId: "MBR00108", name: "Katherine White", phone: "(258) 330-3441",
    planId: "PLAN-DSNP-754", planType: "DSNP",
    claimId: "CLM000484", procedure: "Colonoscopy - Diagnostic", cptCode: "45378",
    denialCode: "CO-97", denialReason: "Benefit included in payment for another service",
    billedAmount: 948.22, agent: "Claim Story Agent",
  },
];

const RESOLVED_SUMMARIES = [
  "Denial explained — provider credentialing gap identified. Member advised to request re-referral from in-network provider.",
  "Claim story delivered. Modifier mismatch corrected; resubmission initiated. Est. resolution: 5–7 days.",
  "Benefits clarified. Deductible balance confirmed at $412. Member enrolled in payment plan.",
  "Prior auth status verified — approval on file. Reprocessing triggered; payment expected within 14 days.",
  "Diagnosis code mismatch explained. Member contacting provider office to update coding and resubmit.",
  "CO-16 resolved — missing NPI added to claim. Corrected claim resubmitted automatically.",
];

const ESCALATED_SUMMARIES = [
  "Coordination of benefits dispute requires manual review by senior adjuster.",
  "ROI not on file for adult dependent — cannot release PHI. Transferred to compliance team.",
  "Filing deadline expired (CO-29) — appeals eligibility must be assessed by human agent.",
  "Non-covered service ruling disputed by member. Escalated to appeals department.",
];

function randomFrom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function formatDuration(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function useTickingTime() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, []);
  return tick;
}

function PulsingDot({ color }: { color: string }) {
  return (
    <span className="relative flex h-2 w-2">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-60" style={{ backgroundColor: color }} />
      <span className="relative inline-flex rounded-full h-2 w-2" style={{ backgroundColor: color }} />
    </span>
  );
}

function AgentDropdown({ agents }: { agents: string[] }) {
  const [isOpen, setIsOpen] = useState(false);
  const finalAgent = agents[agents.length - 1];

  // If only handled by one agent, display plain text
  if (agents.length <= 1) {
    return (
      <span className="text-[11px] text-[#3A3B3D]/70 flex items-center gap-1 font-medium">
        <Cpu size={11} className="text-[#003057]" /> {agents[0]}
      </span>
    );
  }

  return (
    <div className="relative">
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        onBlur={() => setTimeout(() => setIsOpen(false), 200)}
        className="flex items-center gap-1 text-[11px] text-[#3A3B3D]/80 hover:text-[#003057] transition-colors outline-none cursor-pointer"
      >
        <Cpu size={11} className="text-[#003057]" />
        <span className="font-medium text-[#3A3B3D]">{finalAgent}</span>
        <ChevronDown 
          size={11} 
          className={`transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} 
        />
      </button>

      {/* Dropdown Menu (Opens Upwards) */}
      {isOpen && (
        <div
          className="absolute bottom-full left-0 mb-2 w-48 rounded-md bg-white border border-gray-200 shadow-lg z-50 overflow-hidden"
        >
          <div 
            className="px-3 py-2 border-b border-gray-100 text-[9px] font-mono uppercase tracking-wider text-[#003057] bg-slate-50/80" 
          >
            Routing History
          </div>
          <div className="p-2 space-y-0">
            {agents.map((agent, index) => (
              <div key={index} className="flex items-start gap-2 relative">
                {/* Vertical Timeline Line */}
                {index !== agents.length - 1 && (
                  <div className="absolute left-[3px] top-3 w-[1px] h-full bg-gray-200" />
                )}
                <div className="mt-1.5 relative z-10">
                  <div
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ backgroundColor: index === agents.length - 1 ? "#78BE20" : "#cbd5e1" }}
                  />
                </div>
                <span
                  className={`text-[11px] py-0.5 ${
                    index === agents.length - 1 ? "text-[#003057] font-medium" : "text-[#3A3B3D]/60"
                  }`}
                >
                  {agent}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: QueueStatus }) {
  if (status === "connecting") return (
    <span className="flex items-center gap-1.5 text-[11px] font-mono text-amber-600 font-medium">
      <PulsingDot color="#d97706" /> Connecting
    </span>
  );
  if (status === "analyzing") return (
    <span className="flex items-center gap-1.5 text-[11px] font-mono text-[#5C9A1B] font-medium">
      <PulsingDot color="#5C9A1B" /> Analyzing
    </span>
  );
  return (
    <span className="flex items-center gap-1.5 text-[11px] font-mono text-[#5C9A1B] font-medium">
      <PulsingDot color="#5C9A1B" /> Active
    </span>
  );
}

function ActiveCard({ caller, tick }: { caller: ActiveCaller; tick: number }) {
  const elapsed = caller.duration + tick;
  
  // Determine strip color based on status
  const isConnecting = caller.status === "connecting";
  const stripColor = isConnecting ? "#d97706" : "#78BE20"; // Amber or Light Green
  const bgHover = isConnecting ? "rgba(217,119,6,0.03)" : "rgba(120,190,32,0.04)";

  return (
    <div
      className="relative overflow-hidden rounded-lg p-4 bg-white shadow-sm border transition-all duration-200"
      style={{
        borderColor: "rgba(229,231,235,1)",
        borderLeft: `4px solid ${stripColor}`, // The thick left status strip
      }}
      onMouseEnter={(e) => { 
        (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(120,190,32,0.45)";
        (e.currentTarget as HTMLDivElement).style.backgroundColor = bgHover;
      }}
      onMouseLeave={(e) => { 
        (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(229,231,235,1)";
        (e.currentTarget as HTMLDivElement).style.backgroundColor = "#ffffff";
      }}
    >
      {/* Phone number — main identity */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center bg-[#003057]/5 border border-[#003057]/10"
          >
            <ShieldQuestion size={16} className="text-[#003057]" />
          </div>
          <div className="min-w-0">
            <p className="font-mono font-semibold text-base tracking-wide text-[#003057]">
              {caller.phone}
            </p>
            <p className="text-[11px] text-[#3A3B3D]/60 italic">Identity unverified</p>
          </div>
        </div>
        <StatusBadge status={caller.status} />
      </div>

      {/* Claim reason — AI infers this early in the call */}
      <div className="mt-3 space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Using Humana Dark Green (#114A21) here for richer contrast */}
          <span
            className="text-[11px] font-bold uppercase tracking-wider text-[#114A21] bg-[#114A21]/5 px-1.5 py-0.5 rounded"
          >
            {caller.reason}
          </span>
          <ChevronRight size={10} className="text-[#3A3B3D]/40" />
          <span className="text-[11px] text-[#3A3B3D]/80 font-medium truncate">{caller.subReason}</span>
        </div>
        <div className="flex items-center justify-between pt-1">
          <AgentDropdown agents={caller.agents} />
          <span className="font-mono text-[11px] text-[#3A3B3D]/70 flex items-center gap-1 font-medium">
            <Clock size={11} className="text-[#003057]" /> {formatDuration(elapsed)}
          </span>
        </div>
      </div>
    </div>
  );
}

function CompletedCard({ caller }: { caller: CompletedCaller }) {
  const isResolved = caller.outcome === "resolved";
  return (
    <div
      className="relative rounded-lg p-4 bg-white border transition-all duration-300"
      style={
        isResolved
          ? { 
              background: "linear-gradient(135deg, #ffffff 0%, rgba(120,190,32,0.08) 100%)", 
              borderColor: "rgba(120,190,32,0.4)",
              boxShadow: "0 4px 14px rgba(120,190,32,0.18)"
            }
          : { 
              background: "linear-gradient(135deg, #ffffff 0%, rgba(220,80,80,0.08) 100%)", 
              borderColor: "rgba(220,80,80,0.4)",
              boxShadow: "0 4px 14px rgba(220,80,80,0.18)"
            }
      }
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor = isResolved ? "rgba(120,190,32,0.8)" : "rgba(220,80,80,0.8)";
        (e.currentTarget as HTMLDivElement).style.boxShadow = isResolved ? "0 6px 20px rgba(120,190,32,0.3)" : "0 6px 20px rgba(220,80,80,0.3)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor = isResolved ? "rgba(120,190,32,0.4)" : "rgba(220,80,80,0.4)";
        (e.currentTarget as HTMLDivElement).style.boxShadow = isResolved ? "0 4px 14px rgba(120,190,32,0.18)" : "0 4px 14px rgba(220,80,80,0.18)";
      }}
    >
      {/* Identity revealed header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center shadow-sm"
            style={
              isResolved
                ? { background: "rgba(120,190,32,0.15)", border: "1px solid rgba(120,190,32,0.5)" }
                : { background: "rgba(220,80,80,0.15)", border: "1px solid rgba(220,80,80,0.5)" }
            }
          >
            {isResolved
              ? <CheckCircle size={16} style={{ color: "#5C9A1B" }} />
              : <AlertTriangle size={16} style={{ color: "#dc2626" }} />
            }
          </div>
          <div className="min-w-0">
            {/* Name now visible */}
            <div className="flex items-center gap-1.5">
              <p className="font-semibold text-sm text-[#003057] truncate">{caller.name}</p>
              <UserCheck size={11} style={{ color: isResolved ? "#5C9A1B" : "#dc2626" }} />
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <p className="font-mono text-[11px] text-[#3A3B3D]/70">{caller.memberId}</p>
              <span className="text-[#3A3B3D]/30 text-[10px]">·</span>
              <p className="font-mono text-[11px] text-[#3A3B3D]/70">{caller.phone}</p>
            </div>
          </div>
        </div>
        <span
          className="flex-shrink-0 text-[10px] font-mono font-bold uppercase tracking-wide px-2.5 py-1 rounded-full shadow-sm"
          style={
            isResolved
              ? { background: "#78BE20", color: "#ffffff" }
              : { background: "#dc2626", color: "#ffffff" }
          }
        >
          {isResolved ? "AI Resolved" : "Escalated"}
        </span>
      </div>

      {/* Claim details */}
      <div className="mt-4 space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-[#003057]/5 text-[#003057] font-medium border border-[#003057]/10">
            {caller.claimId}
          </span>
          <span className="text-[11px] text-[#3A3B3D]/80 font-bold">{caller.reason}</span>
        </div>
        <p className="text-[11px] text-[#3A3B3D] leading-relaxed">{caller.summary}</p>
        <div className="flex items-center justify-between pt-2">
          <AgentDropdown agents={caller.agents} />
          <span className="font-mono text-[11px] text-[#3A3B3D]/70 flex items-center gap-1 font-medium">
            <Clock size={11} className="text-[#003057]" /> {formatDuration(caller.duration)}
          </span>
        </div>
      </div>
    </div>
  );
}

function StatPill({ label, value, color }: { label: string; value: number | string; color: string }) {
  return (
    <div 
      className="flex items-center gap-2 rounded-md px-3 py-1.5 backdrop-blur-md shadow-sm border"
      style={{ 
        background: "rgba(255, 255, 255, 0.25)", // Semi-transparent to let the green shine through
        borderColor: "rgba(255, 255, 255, 0.45)" // Frosted glassy edge
      }}
    >
      <span 
        className="w-2 h-2 rounded-full border border-white/60 shadow-sm" 
        style={{ backgroundColor: color }} 
      />
      <span className="font-mono text-xs font-semibold text-[#003057]/90">{label}</span>
      <span className="font-mono text-xs font-bold text-[#003057]">{value}</span>
    </div>
  );
}

const usedIndices = new Set<number>();
function pickUnused(): MemberRecord {
  if (usedIndices.size >= MEMBER_POOL.length) usedIndices.clear();
  let idx: number;
  do { idx = Math.floor(Math.random() * MEMBER_POOL.length); } while (usedIndices.has(idx));
  usedIndices.add(idx);
  return MEMBER_POOL[idx];
}

function generateAgentPath(primaryAgent: string): string[] {
  const path = ["Routing Orchestrator"]; 
  if (Math.random() > 0.6 && primaryAgent !== "ROI Gatekeeper") {
    path.push("ROI Gatekeeper"); 
  }
  if (primaryAgent !== "Routing Orchestrator") {
    path.push(primaryAgent);
  }
  return Array.from(new Set(path)); 
}

function makeActiveCaller(id: string, duration = 0, status: QueueStatus = "connecting"): ActiveCaller {
  const rec = pickUnused();
  return {
    id,
    phone: rec.phone,
    reason: rec.procedure,
    subReason: `${rec.denialCode} — ${rec.denialReason}`,
    agents: generateAgentPath(rec.agent),
    duration,
    status,
    _record: rec,
  };
}

export default function App() {
  const tick = useTickingTime();
  const counter = useRef(0);

  const [queue, setQueue] = useState<ActiveCaller[]>(() =>
    Array.from({ length: 4 }, (_, i) =>
      makeActiveCaller(
        `c${i}`,
        Math.floor(30 + Math.random() * 180),
        randomFrom(["active", "active", "analyzing", "connecting"] as QueueStatus[])
      )
    )
  );

  const [completed, setCompleted] = useState<CompletedCaller[]>(() =>
    Array.from({ length: 5 }, (_, i) => {
      const rec = pickUnused();
      const outcome: OutcomeStatus = i < 3 ? "resolved" : "escalated";
      return {
        id: `d${i}`,
        phone: rec.phone,
        name: rec.name,
        memberId: rec.memberId,
        planId: rec.planId,
        claimId: rec.claimId,
        reason: rec.procedure,
        agents: generateAgentPath(rec.agent),
        outcome,
        duration: Math.floor(90 + Math.random() * 300),
        summary: randomFrom(outcome === "resolved" ? RESOLVED_SUMMARIES : ESCALATED_SUMMARIES),
        completedAt: new Date(Date.now() - Math.random() * 3600000),
      };
    })
  );

  useEffect(() => {
    if (queue.length === 0) return;
    const delay = 12000 + Math.random() * 8000;
    const id = setTimeout(() => {
      setQueue((q) => {
        if (q.length === 0) return q;
        const idx = Math.floor(Math.random() * q.length);
        const caller = q[idx];
        const outcome: OutcomeStatus = Math.random() > 0.28 ? "resolved" : "escalated";
        const done: CompletedCaller = {
          id: caller.id,
          phone: caller.phone,
          name: caller._record.name,
          memberId: caller._record.memberId,
          planId: caller._record.planId,
          claimId: caller._record.claimId,
          reason: caller.reason,
          agents: caller.agents, 
          outcome,
          duration: caller.duration + Math.floor(Math.random() * 60),
          summary: randomFrom(outcome === "resolved" ? RESOLVED_SUMMARIES : ESCALATED_SUMMARIES),
          completedAt: new Date(),
        };
        setCompleted((prev) => [done, ...prev].slice(0, 20));
        return q.filter((_, i) => i !== idx);
      });
    }, delay);
    return () => clearTimeout(id);
  }, [queue]);

  useEffect(() => {
    const delay = 8000 + Math.random() * 7000;
    const id = setTimeout(() => {
      const newId = `c${counter.current++}`;
      const newCaller = makeActiveCaller(newId, 0, "connecting");
      setQueue((q) => [...q, newCaller]);
      setTimeout(() => {
        setQueue((q) => q.map((c) => c.id === newId ? { ...c, status: "active" as QueueStatus } : c));
      }, 3000);
    }, delay);
    return () => clearTimeout(id);
  }, [queue]);

  const resolvedCount = completed.filter((c) => c.outcome === "resolved").length;
  const escalatedCount = completed.filter((c) => c.outcome === "escalated").length;
  const fcr = completed.length > 0 ? Math.round((resolvedCount / completed.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#f9fafb] text-[#3A3B3D]" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>

      {/* Header */}
      <header
        className="sticky top-0 z-10 shadow-sm border-b backdrop-blur-lg"
        style={{ backgroundColor: "rgba(120, 190, 32, 0.85)", borderColor: "rgba(92, 154, 27, 0.5)" }}
      >
        {/* Changed py-3 to py-5 to make the header taller */}
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Changed h-8 to h-10 and slightly increased padding so the logo grows with the header */}
            <div className="bg-white px-2.5 py-1.5 rounded shadow-sm h-10 flex items-center justify-center">
              <img 
                src={humanaLogo}
                alt="Humana Logo" 
                className="h-full w-auto object-contain mix-blend-multiply"
              />
            </div>
            <span className="font-bold text-lg tracking-tight text-[#003057]">Claim Story AI</span>
            <span className="text-[#003057]/30 text-xl select-none">|</span>
            <span className="text-sm font-semibold text-[#003057]/80">Call Center Operations</span>
          </div>
          <div className="flex items-center gap-4">
            <StatPill label="In Queue" value={queue.length} color="#003057" />
            <StatPill label="Resolved" value={resolvedCount} color="#78BE20" />
            <StatPill label="Escalated" value={escalatedCount} color="#dc2626" />
            <StatPill label="FCR" value={`${fcr}%`} color="#5C9A1B" />
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

          {/* Active Queue */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <Phone size={16} className="text-[#003057]" />
                <h2 className="font-bold text-sm text-[#003057]">Active Queue</h2>
                <span className="font-mono font-bold text-[11px] px-2 py-0.5 rounded-full bg-[#003057]/10 text-[#003057]">
                  {queue.length}
                </span>
              </div>
              <span className="text-[11px] text-[#5C9A1B] font-mono font-medium flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full animate-pulse inline-block" style={{ backgroundColor: "#5C9A1B" }} />
                Live
              </span>
            </div>

            {/* Explanation chip */}
            <div className="flex items-center gap-1.5 mb-3 px-1">
              <ShieldQuestion size={11} className="text-[#3A3B3D]/50" />
              <span className="text-[11px] font-medium text-[#3A3B3D]/60">Caller identity hidden until verified by AI</span>
            </div>

            <div className="space-y-3">
              {queue.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 border border-dashed rounded-lg bg-white" style={{ borderColor: "rgba(0,48,87,0.15)" }}>
                  <Phone size={24} className="text-[#003057]/20 mb-2" />
                  <p className="text-sm font-medium text-[#3A3B3D]/60">Queue is empty</p>
                </div>
              ) : (
                queue.map((caller) => <ActiveCard key={caller.id} caller={caller} tick={tick} />)
              )}
            </div>
          </section>

          {/* Completed */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <PhoneOff size={16} className="text-[#003057]" />
                <h2 className="font-bold text-sm text-[#003057]">Completed</h2>
                <span className="font-mono font-bold text-[11px] px-2 py-0.5 rounded-full bg-[#3A3B3D]/10 text-[#3A3B3D]">
                  {completed.length}
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] font-mono text-[#3A3B3D]/70 font-medium">
                <span className="flex items-center gap-1">
                  <CheckCircle size={10} style={{ color: "#5C9A1B" }} /> {resolvedCount} resolved
                </span>
                <span className="flex items-center gap-1">
                  <AlertTriangle size={10} style={{ color: "#dc2626" }} /> {escalatedCount} escalated
                </span>
              </div>
            </div>

            {/* Legend */}
            <div className="flex items-center gap-4 mb-3 px-1">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-[#78BE20]/20 border border-[#78BE20]" />
                <span className="text-[11px] font-medium text-[#3A3B3D]/60">AI resolved — name revealed</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-red-100 border border-red-400" />
                <span className="text-[11px] font-medium text-[#3A3B3D]/60">Escalated to human agent</span>
              </div>
            </div>

            <div className="space-y-3">
              {completed.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 border border-dashed rounded-lg bg-white" style={{ borderColor: "rgba(0,48,87,0.15)" }}>
                  <CheckCircle size={24} className="text-[#003057]/20 mb-2" />
                  <p className="text-sm font-medium text-[#3A3B3D]/60">No completed calls yet</p>
                </div>
              ) : (
                completed.map((caller) => <CompletedCard key={caller.id} caller={caller} />)
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}