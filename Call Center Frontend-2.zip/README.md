
  # Call Center Frontend

  This is a code bundle for Call Center Frontend. The original project is available at https://www.figma.com/design/Q7cZue487i2lazZrLgJ1s2/Call-Center-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  